#/bin/bash

rm -rf logs
rm -rf drives
mkdir logs 
mkdir drives

echo "Collecting data..."
for i in {0..3}
do
for j in {0..7}
do
	ssh blc$i$j "./megaraid.sh" >> drives/blc$i$j.txt	
        
done
done

for i in {0..5}
do
	ssh bls$i "./megaraid.sh" >> drives/bls$i.txt
done

for i in {0..3}
do 
for j in {0..7}
do 
	echo blc$i$j
	mkdir logs/blc$i$j
	while read line; do
		echo $line | cut -d ":" -f 3 >> temp$i$j.txt
		while read megaraidnum; do
	        ssh blc$i$j "sudo smartctl -a -d megaraid,$megaraidnum /dev/sda" >> logs/blc$i$j/hw$megaraidnum.txt & 
		done<temp$i$j.txt
		for job in `jobs -p`
		do
			wait $job
		done
		rm temp$i$j.txt
	done<drives/blc$i$j.txt
done
done

rm -rf gpu
mkdir gpu

for i in {0..3}
do
for j in {0..7}
do
	echo "gpu"blc$i$j
	ssh blc$i$j "nvidia-smi -query-gpu=gpu_name,gpu_serial,memory.total,clocks.max.gr,clocks.max.sm,clocks.max.memory --format=csv" >> gpu/blc$i$j.txt &
done
done

for i in {0..5}
do
        echo bls$i
        mkdir logs/bls$i
        while read line; do
                echo $line | cut -d ":" -f 3 >> temp$i.txt
                while read megaraidnum; do
                ssh bls$i "sudo smartctl -a -d megaraid,$megaraidnum /dev/sda" >> logs/bls$i/hw$megaraidnum.txt & 
                done<temp$i.txt
		for job in `jobs -p`
                do
                        wait $job
                done
                rm temp$i.txt
        done<drives/bls$i.txt
done

for i in {0..5}
do
        echo "gpu"blc$i
        ssh bls$i "nvidia-smi -query-gpu=gpu_name,gpu_serial,memory.total,clocks.max.gr,clocks.max.sm,clocks.max.memory --format=csv" >> gpu/bls$i.txt &
done

