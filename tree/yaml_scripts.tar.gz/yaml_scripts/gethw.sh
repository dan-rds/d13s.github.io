#!/bin/bash

rm -f final*.txt
rm hwdimm.txt
rm -f output*.txt
NODE=$1
file="output$NODE"
tp="null"
echo "device: " >> $file.txt
echo " hostname: $NODE" >> $file.txt 
echo " observatory: Green Bank" >> $file.txt
type=$(echo $NODE | cut -c1-3)
if [ $type == "blc" ] 
then
	echo " type: COMPUTE" >> $file.txt
	tp="compute"
else
	echo " type: STORAGE" >> $file.txt
	tp="storage"
fi
ssh $NODE "cat /proc/cpuinfo" >> temp.txt
number=$(grep "processor" temp.txt)  
cpu=$(grep "model name" temp.txt)
cores=$(grep "cores" temp.txt)
rm temp.txt
lscpu >> temp.txt
hyperthreading=$(grep "Thread(s)" temp.txt)
echo $number >> hwnumbers.txt
echo $cpu >> hwcpu.txt
echo $cores >> hwcores.txt
echo $hyperthreading >> hwhyp.txt
python3 yaml.py "cpu" $NODE
rm hwnumbers.txt hwcpu.txt hwcores.txt hwhyp.txt temp.txt
python3 yaml.py "disk" $NODE
ssh $NODE "cat /proc/meminfo | sed -n '1p'" >> hwmem.txt
ssh $NODE "sudo dmidecode" >> hwdimm.txt
python3 yaml.py "memory" $NODE
rm hwmem.txt
if [ $tp  == "compute" ]
then
	ssh $NODE "nvidia-smi --query-gpu=gpu_name,gpu_serial,memory.total,clocks.max.gr,clocks.max.sm,clocks.max.memory --format=csv" >> gpu$NODE.txt
	python3 yaml.py "gpu" $NODE
	rm gpu$NODE.txt
	cat output$NODE.txt finaloutputcpu.txt finaloutputmemt.txt finaloutputgpu.txt finaloutputdisk.txt > $NODE"data".txt
else 
	cat output$NODE.txt finaloutputcpu.txt finaloutputmemt.txt finaloutputdisk.txt > $NODE"data".txt
fi

 
