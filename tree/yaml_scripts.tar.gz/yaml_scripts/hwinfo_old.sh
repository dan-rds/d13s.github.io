#!/bin/bash


rm -f  hwinfo.txt
HW=$1
NODE=$2
for file in logs/$NODE/*.txt; do
	totaldata=$(sed -n '5, 19p' $file | grep $HW)
	echo "${file%.txt} $totaldata" >> hwinfo.txt 
done

python3 identifyrange.py $NODE | while read var; do
	echo $var >> loop.txt
done
start=$(sed '1q;d' loop.txt)
end=$(sed '2q;d' loop.txt)
rm loop.txt
for i in $(eval echo {$start..$end})
do

	curr=$(grep -s "logs/blc$i" hwinfo.txt)
	found=$(echo $?)
	if [ $found -eq 0 ]; then
		echo $curr >> hwrite.txt;
	else
		echo "logs/blc$i Does not exist" >> hwrite.txt;
	fi
done
rm hwinfo.txt
while read line; do
	echo $(python3 trim.py $HW $start $line)
	start=$((start+1))
done <hwrite.txt
rm hwrite.txt
