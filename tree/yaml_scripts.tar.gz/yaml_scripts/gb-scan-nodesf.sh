#!/bin/bash

drive1="datax"
drive2="datax2"

for k in {0..3}
do 
for j in {0..7}
do
	prefix="blc"
	i=$prefix$k$j
	echo $i
	ssh $i "cd /datax && du -s */" >> logs/$i$drive1.txt 
	ssh $i "cd /datax2 && du -s */" >> logs/$i$drive2.txt 

done
done



